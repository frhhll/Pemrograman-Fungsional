import matplotlib.pyplot as plt

x = [1, 2, 3, 4, 5]
y = [3, 7, 2, 8, 5]

# plt.scatter(x, y)
plt.scatter(x,y, label="sX", marker="*", color="hotpink")

plt.show()